<?php
session_start();
session_destroy();
require"index.php";

?>