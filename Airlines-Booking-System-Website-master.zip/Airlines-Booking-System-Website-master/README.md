# Airlines Booking System   using HTML,CSS,PHP,MYSQL.

if you want To run my code store these files into your "www" directory

And Create your sql database  with Database Name: airlines
           and tables as per in "airlines.sql" file  

