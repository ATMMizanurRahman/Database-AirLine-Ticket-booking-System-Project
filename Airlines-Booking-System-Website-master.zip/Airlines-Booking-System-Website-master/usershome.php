<html>
<head>
	<title>AirlinesBookingSystem</title>
	<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="layoutsstyle.css">
</head>
  
    <body>
    	<div class="header">
    		<h1>Airlines Booking Platform</h1>
    		<p>Book Flight tickets and Keep track of your Booking History</p>
    	</div>
    	<div class="topnav">
    		<a href="profile.php">Profile</a>
    		<a href="usershome.php">Home</a>
    		<a href="booktickets.php">Book Flight Ticktets</a>
    		<a href="bookinghistory.php">Your Booking History</a>

    	</div>
  
  <div class="column">
    <h2>Main Content</h2>
    <p>Hai User </p>
  </div>
  
 

	
	
<!-- 		<form action="booktickets.php" method="POST">
			<input type="hidden" name="email" value="<?php echo$email; ?>">
			<button class="btn info" type="submit">Book Flights</button>
        </form>
        <form action="bookinghistory.php" method="POST">
        	<input type="hidden" name="email" value="<?php echo$email; ?>">
        	<button class="btn info" type="submit">Your Booking History</button>
        </form> -->
<!--         <ul>
        	<li><a href="booktickets.php">Book Tickets</a></li>
        	<li><a href="bookinghistory.php">Booking History</a></li>
        </ul> -->
	
    </body>
 </html>