<?php
  $host = "localhost";
  $user = "root";
  $dbpass = "";
  $dbname = "airlines";
  // $name="shivaveldi";
  // $email="shiva@gmail.com";
  // $password="shiva";
  $con = mysqli_connect($host,$user,$dbpass,$dbname);
   // $sql=mysqli_query($con,"insert into users_1 (name,email,password) values ('$name','$email','$password')");
   // if($sql)echo"data inserted succesfully";
   // else echo"error in inserting data";  
  
?>
